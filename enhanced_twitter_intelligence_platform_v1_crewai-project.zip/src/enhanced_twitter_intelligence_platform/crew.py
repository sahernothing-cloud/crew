import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	SerperDevTool,
	ScrapeWebsiteTool,
	FirecrawlSearchTool
)





@CrewBase
class EnhancedTwitterIntelligencePlatformCrew:
    """EnhancedTwitterIntelligencePlatform crew"""

    
    @agent
    def advanced_twitter_content_discovery_specialist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["advanced_twitter_content_discovery_specialist"],
            
            
            tools=[				SerperDevTool(),
				ScrapeWebsiteTool(),
				FirecrawlSearchTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def twitter_news_report_generator(self) -> Agent:
        
        return Agent(
            config=self.agents_config["twitter_news_report_generator"],
            
            
            tools=[],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def date_helper_specialist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["date_helper_specialist"],
            
            
            tools=[],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    

    
    @task
    def generate_3_day_date_range(self) -> Task:
        return Task(
            config=self.tasks_config["generate_3_day_date_range"],
            markdown=False,
            
            
        )
    
    @task
    def advanced_twitter_discovery_url_extraction(self) -> Task:
        return Task(
            config=self.tasks_config["advanced_twitter_discovery_url_extraction"],
            markdown=False,
            
            
        )
    
    @task
    def generate_twitter_news_report(self) -> Task:
        return Task(
            config=self.tasks_config["generate_twitter_news_report"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the EnhancedTwitterIntelligencePlatform crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
            chat_llm=LLM(model="openai/gpt-4o-mini"),
        )


